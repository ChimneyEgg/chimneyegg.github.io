Wotansauge			::		Chimney Eggs
						chimneysandeggs@gmail.com

VERSION				::		07_21_23::0.1.0


CONTROLS:
- W/A/S/D 			:: 		Movement
- Arrow Keys 			:: 		Change Direction
- E				::		Interact/Use
- Q				::		Drop
- ~				::		Open Console
		

CONSOLE CMDS:
- ni/new_item [Full Name]	::		Spawn a new item into the player's hand
- lt/light_toggle		::		Toggles lighting
- hud				::		Toggles the 'hud'
- re/reload			::		Reloads the game


GENERAL:
- All items can be used and can have effects on you and the world
- Hunger will eventually slow you
- There's nothing hiding in the darkness :)


ITEM LIST:
- Wotansauge.Items.Atine
- Wotansauge.Items.Lantern
- Wotansauge.Items.LightBulb
- Wotansauge.Items.Myc
- Wotansauge.Items.Pickaxe
- Wotansauge.Items.Rocks
- Wotansauge.Items.Shroom


LICENSE:

pls don't claim u made it, thx bai <3