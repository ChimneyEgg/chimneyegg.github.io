# 0.5.0 - The Update Where I Forgot What I Added 
- Lol hav fun

# 0.4.1 - Paper Alibis
- Added treasure maw
- Added stone tile
- Added puddles to Roots
- Added BIG Digger, Caller Plant
- Added tin pickaxe + recipe
- Added knapsack crafting recipe
- Fixed ability for enemies to ride rails
- Changed flyrock description
- Removed Flycaves ( for now )
- Began work on Tunnels 

# 0.4.0 - Wintergreen
- Added ability for enemies to wander about, be shortsighted, and varying spatial awareness
- ( Essentially overhauled AI )
- Added extra effects to FOOT enemy
- Added rock particle
- Added Krab
- Added knapsack, and rucksack
- Added cloth, ruby cloth, and sapphire cloth
- Added cover
- Added hoe, and soil
- Added fire throw
- Reworked a lot of crafting recipes
- Reworked items that a lot now have durability
- Reworked version numbering
- Reworked roots layer
- Reworked AI and detection ranges of enemies
- Began work on Flycaves

# 0.3.0 ( 0.1.3 ) - Elephant Bones
- Added swimming " animation "
- Added FOOT, Gulper, Wanderer enemies
- Added tumbleweed
- Added teleport command
- Added '?' option to all commands
- Added secret
- Fixed a window scaling issue
- Began work on the Wastes layer

# 0.2.1 ( 0.1.2_02 ) - Lighting fix
- Fixed a lighting bug when switching layers

# 0.2.0 ( 0.1.2 ) - Salty, Salted, Saline and Salt
- Added rails
- Added rubble
- Added damage mechanic / game over
- Added spiky stone
- Added salt tile
- Added water tile
- Added fishies
- Added god command
- Added switch_layer command
- Began work on the Saltine layer

# 0.1.1 - Getting Back There With A Side Of Pepper

- Added fireplace
- Added wood 
- Added mud
- Added blackpowder vase
- Added root structure(s)
- Added tin/ore 
- Added firestarter
- Added New_Tile command
- Added descriptions/examinations
- Added muddied stick
- Added stars (Tile)
- Added scarlet ruby and violet sapphire
- Added flyrock
- Added npc / pathfinding ai
- Added discord "rich presence" integration
- Changed pickaxe from doing 1 hit point, to 0.5 hit points
- Reworked hunger mechanic