Wotansauge				::		Chimney Eggs
								chimneysandeggs@gmail.com

VERSION					::		09_15_23::0.4.1


CONTROLS:
- W/A/S/D 			:: 		Movement
- Arrow Keys 		:: 		Change Direction
- E					::		Interact/Use
- Q					::		Drop
- X					::		Inspect
- ~					::		Open Console
		

CONSOLE CMDS:
- ni/new_item [Full Name] [x] [y]	::		Spawn a new item
- nt/new_tile [Full Name] [x] [y] 	::		Create a new tile 
- nn/new_npc [Full Name] [x] [y]	::		Spawn a new NPC
- lt/light_toggle					::		Toggles lighting
- hud								::		Toggles the 'hud'
- re/reload							::		Reloads the game
- css/change_sampler_state			::		Changes the sampler state
- god								::		Toggles god mode
- tp/teleport [x] [y]			::		Teleports the player
- sl/switch_layer [Full Name]		::		Switches layers/rooms 
Additionally '?' option 

GENERAL:
- Using the Inspect key on items, tiles, etc; is key ( pun intended ) to figure out everything
- ( Most ) items can be used and can have effects on you and the world
- Dropping items onto eachother can craft new items
- Hunger will eventually slow you 
- There's something hiding in the darkness :)

HINT:
- The roots lining the walls can be used to obtain wood!
- Fish will naturally appear after a while
- Tumbleweeds contain lots of goodies
- It's best to have a central point of operations before venturing out
- They can hear you...

LICENSE:

pls don't claim u made it, thx bai <3